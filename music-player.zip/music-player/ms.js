
let b1 = document.querySelector(".one");
let b2 = document.querySelector(".two");
let b3 = document.querySelector(".three");

let playBtn = document.querySelector(".play-btn");
let nextBtn = document.querySelector(".fa-circle-arrow-right");
let prevBtn = document.querySelector(".fa-circle-arrow-left");

let obj = [
    {
        image: "images/bad-boy.jpeg",
        song:"songs/bad-boy.mp3",
        duration:"03:27",
        second:"207",
    },
    {
        image: "images/baawala.jpeg",
        song:"songs/baawla.mp3",
        duration:"03:02",
        second:"182",
    },
    {
        image: "images/chocolate.jpeg",
        song:"songs/chocolate.mp3",
        duration:"02:44",
        second:"104",
    },
    {
        image: "images/goa-beech.jpeg",
        song:"songs/goa-beech.mp3",
        duration:"03:40",
        second:"220",
    },
    {
        image: "images/oops.jpeg",
        song:"songs/oops.mp3",
        duration:"02:57",
        second:"177",
    },
    {
        image: "images/sajana.jpeg",
        song:"songs/sajana.mp3",
        duration:"02:42",
        second:"162",
    },
    {
        image: "images/sawariya.jpeg",
        song:"songs/sawariya.mp3",
        duration:"03:24",
        second:"204",
    },
    {
        image: "images/shona.jpeg",
        song:"songs/shona.mp3",
        duration:"02:51",
        second:"171",
    }
]
let progBar = document.getElementById("prog");
let sM = document.querySelector(".minute");
let sS = document.querySelector(".second");
console.log(sM.innerText,sS.innerText);
let j=0,k=1,l=2;
b1.style.backgroundImage = `url(${obj[j].image})`;
b2.style.backgroundImage = `url(${obj[k].image})`;
b3.style.backgroundImage = `url(${obj[l].image})`;
let audio = document.getElementById("audio");
let durationSong = document.querySelector(".end");
durationSong.innerText=obj[k].duration;

let m=0;
let leng = obj.length;
let pr=0,seconds=0,minute=0;
let prId=null;


//=============== next song
nextBtn.addEventListener("click",()=>{
    j--;
    if( j<0)
        j=leng-1;
    b1.style.backgroundImage = `url(${obj[j].image})`;
    k--;
    if( k<0)
        k=leng-1;
    b2.style.backgroundImage = `url(${obj[k].image})`;
    durationSong.innerText = obj[k].duration;
    audio.src=obj[k].song;
    l--;
    if( l<0)
        l=leng-1;
    b3.style.backgroundImage = `url(${obj[l].image})`; 
    
    if( m==1 ){
        playBtn.classList.remove('fa-circle-pause');
        m=0;
    } 
    progBar.value=0;
    pr=0;
    seconds=0;
    minute=0;
    clearInterval(prId);
    sS.innerText="00";
    sM.innerText="00";
})


//=============== previous song
prevBtn.addEventListener("click",()=>{
    j++;
    if( j>leng-1)
        j=0;
    b1.style.backgroundImage = `url(${obj[j].image})`;
    k++;
    if( k>leng-1)
        k=0;
    b2.style.backgroundImage=`url(${obj[k].image})`;
    durationSong.innerText = obj[k].duration;
    audio.src=obj[k].song;
    l++;
    if( l>leng-1 )
        l=0;    
    b3.style.backgroundImage=`url(${obj[l].image})`;
        
    if( m==1 ){
        playBtn.classList.remove('fa-circle-pause');
        m=0;
    }      
    progBar.value=0;
    pr=0;
    seconds=0;
    minute=0;
    clearInterval(prId);
    sS.innerText="00";
    sM.innerText="00";
})


//================ manual change status 
// function changed(){
//     // console.log(progBar.value);
//     let percent = obj[k].second/100;
//     let progression = Math.round(percent*progBar.value);
//     // console.log(progression);
//     seconds = progression%60;
//     minute = progression/60;
//     console.log(seconds,minute);

// }
//============== progressive bar
function progress(){

    
    if(seconds<10)
        sS.innerText = `0${seconds}`;
    else
        sS.innerText = seconds;
    sM.innerText=`0${minute}`;

    

    progBar.value= ( (pr/obj[k].second)*100);
    if(seconds>59){
        seconds=0;
        minute++;
    }
    // pr means total progress in seconds
    console.log(pr++,seconds++,minute);
    if( pr > obj[k].second){
        playBtn.classList.remove('fa-circle-pause');
        m=0;
        pr=0;
        seconds=0;
        minute=0;
        clearInterval(prId);
    }
}

//=============== play button
playBtn.addEventListener("click",()=>{
     
    if(m==0){
        playBtn.classList.add('fa-circle-pause');
        audio.play();
        m=1;
        prId = setInterval("progress()",1000);
    }else{
        playBtn.classList.remove('fa-circle-pause');
        m=0;
        audio.pause();
        clearInterval(prId);
    }  
})



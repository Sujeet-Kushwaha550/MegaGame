import pygame
import random
import sys 

pygame.init()
clock = pygame.time.Clock()

# Background wallpaper
backgroundWallpaper = pygame.transform.scale(pygame.image.load("space_game/background2.jpg"),(900,600))

# Blast image loading
renderWhenBlast = pygame.transform.scale(pygame.image.load("space_game/blast.png"),(400,100))
blast = False

# Giving interval between rendering the enemy ship
time_interval_enemy_ship_render = 1000
custom_event_ship_rendering = pygame.USEREVENT+1
pygame.time.set_timer(custom_event_ship_rendering,time_interval_enemy_ship_render)



# Setting the font of score board
score_board_font = pygame.font.Font(None,40)
score=0



# Hero space craft
hero_space_craft=pygame.transform.scale(pygame.image.load("space_game/hero_ship.png"), (60,60))

space_craft_position_x, space_craft_position_y=450,520

def space_craft(keys):
    global space_craft_position_y,space_craft_position_x
    if keys[pygame.K_LEFT] and space_craft_position_x>30:
        space_craft_position_x-=10
    if keys[pygame.K_RIGHT] and space_craft_position_x<870:
        space_craft_position_x+=10
    if keys[pygame.K_UP] and space_craft_position_y>80:
        space_craft_position_y-=10
    if keys[pygame.K_DOWN] and space_craft_position_y<550:
        space_craft_position_y+=10
    return space_craft_position_x,space_craft_position_y

        
# rendering the space craft on the screen
def renderSpaceCraft():
    screen.blit(hero_space_craft,(space_craft_position_x,space_craft_position_y))
    
# rendering enemy ship
# This is class for falling the enemy ship
class EnemeyShip:
    x,y,speed=0,-10,0
    image,enemy_space_craft='',''

# Bullet class for hero ship
class Bullets:
    bulletx,bullety,bullet_speed=0,0,0.1
    bx,by=0,0
    bullet_image=pygame.transform.rotate(pygame.transform.scale(pygame.image.load("space_game/bullets.png"),(60,50)),90)

# List for bullet object
bullets_shooting = []

# Firing bullets function 
def rendering_bullet():
    for bullet in bullets_shooting:
        screen.blit(bullet.bullet_image,(bullet.bulletx,bullet.bullety))
        screen.blit(bullet.bullet_image,(bullet.bx,bullet.by))
        
def create_bullets(ship_x,ship_y):
    new_bullet = Bullets()
    new_bullet.bulletx = ship_x+28
    new_bullet.bullety = ship_y
    new_bullet.bx = ship_x-15
    new_bullet.by = ship_y
    bullets_shooting.append(new_bullet)
    
falling_objects=[]

enemyShipList = ["space_game/enemy_ship_1.png","space_game/enemey_ship_2.png","space_game/enemey_ship_3.png"]

# Generate new falling objects
def create_enemy_ship():
    new_object = EnemeyShip()
    
    new_object.image = random.choice(enemyShipList)
    # print(new_object.image)
    
    new_object.enemy_space_craft =  pygame.transform.rotate(pygame.transform.scale(pygame.image.load(new_object.image), (60,60)),180)
     
    new_object.x = random.randint(0,870)
    new_object.y = 0
    new_object.speed = random.randint(1,3)
    # print(new_object.x)
    falling_objects.append(new_object)

# putting images of enemy ship
def rendering_enemy_ship():   
    # Draw the falling objects
    for obj in falling_objects:
        screen.blit(obj.enemy_space_craft,(obj.x,obj.y))
    
    
# setting display
screen = pygame.display.set_mode((900,600))
pygame.display.set_caption("Space Shooting Game")

game_run = True
gameOver = False
showGameOverDisplay = False


# This helps us to perform task on key press continously
pygame.key.set_repeat(200,50)

# Adding bacckground music
pygame.mixer.init()
pygame.mixer.music.load("space_music/music1.mp3")
pygame.mixer.music.set_volume(.5)
pygame.mixer.music.play(-1)
# Adding firing sound
fire_sound = pygame.mixer.Sound("space_music/laserGunShot1.mp3")
fire_sound.set_volume(.9)
# Adding blast sound effect
blast_sound = pygame.mixer.Sound("space_music/blastSound.mp3")
blast_sound.set_volume(.9)
# Adding gameover sound effect
gameover_sound = pygame.mixer.Sound("space_music/gameOver.mp3")
gameover_sound.set_volume(.9)
playSound = True
# Addimg enemy ship blast sound effect 
enemy_ship_sound = pygame.mixer.Sound("space_music/enemyShipBlast.mp3")
# enemy_ship_sound.set_volume(1)

# Delay the game over screen
delayTheGameOver=True


# Creating Moving stars in the background

class MovingStars:
    star_x,star_y,star_r,star_s=0,0,0,0
    

numberOfStars=[]
star=''
def createStars():
    new_star = MovingStars()
    new_star.star_x=random.randint(0,900)
    new_star.star_y=20
    new_star.star_s=0.1  
    
    new_star.star_r = random.randint(1,2)
    new_star.star_s = random.random()
    numberOfStars.append(new_star)

def star_redering():
    global star
    for s in numberOfStars:
        pygame.draw.circle(screen,(255,255,255),(s.star_x,s.star_y),s.star_r)
    
for i in range(20):
    createStars()
    for s in numberOfStars:
        s.star_y = random.randint(0,600)

# Game running 

while game_run:
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            game_run=False
        if e.type == custom_event_ship_rendering:
            create_enemy_ship() 
            for i in range(5):
                createStars()
            if gameOver:
                showGameOverDisplay=True
                
        if not blast:
            keys = pygame.key.get_pressed()            
            
        position_of_ship = space_craft(keys)       
        
        # Firring bullets on click of Space Bar
        if e.type == pygame.KEYDOWN and not blast:
            if e.key == pygame.K_SPACE:
                create_bullets(position_of_ship[0],position_of_ship[1])
                fire_sound.play()
                
    # Falling stars
    for s in numberOfStars:
        s.star_y+=s.star_s
    
    # Update the positions of bullets
    if not blast:
        for bullets in bullets_shooting:
            for i in range(10):
                bullets.bullety -= 1
                bullets.by -= 1                        
            
    # List comprehension for bullets
    bullets_shooting = [bullets for bullets in bullets_shooting if bullets.bullety>-5]
    
    # Update the positions of falling objects
    if not blast:
        for obj in falling_objects:
            obj.y += obj.speed
    
    # Killing enemy ships
    for enemy_ship in falling_objects:
        for bullets in bullets_shooting:
            if abs(enemy_ship.x - bullets.bx) < 40 and abs(enemy_ship.y - bullets.by) < 40 or abs(enemy_ship.x - bullets.bulletx) < 40 and abs(enemy_ship.y - bullets.bullety) < 40:
                falling_objects.remove(enemy_ship)
                bullets_shooting.remove(bullets)
                enemy_ship_sound.play()
                score += 5
                
    # Game over condition
    for enemy_ship in falling_objects:
        if abs(enemy_ship.x - space_craft_position_x) < 40 and abs(enemy_ship.y - space_craft_position_y) < 40:
            gameOver=True
            falling_objects.remove(enemy_ship)
            blast_sound.play()
            blast = True        
        
    # Remove objects that have fallen off the screen
    falling_objects = [obj for obj in falling_objects if obj.y < 600]
    
    
    # Window background
    screen.blit(backgroundWallpaper,(0,0))
    star_redering()
    rendering_enemy_ship()
    rendering_bullet()
    renderSpaceCraft()
    
    if blast:
        screen.blit(renderWhenBlast,(space_craft_position_x-180,space_craft_position_y-25))
        pygame.mixer.music.stop()
        
    # rendering score on score board
    score_display = score_board_font.render(f"Score: {score}",True,(0,0,255)) 
    screen.blit(score_display,(380,10)) 
    
    # Gameover board    
    if showGameOverDisplay:
        if delayTheGameOver:
            pygame.time.delay(3000)
            delayTheGameOver = False
        gameOverImage = pygame.transform.scale(pygame.image.load("space_game/gameover1.jpg"),(900,600))
        screen.blit(gameOverImage,(0,0))
        pygame.display.update()
        if playSound:
            gameover_sound.play()
            playSound=False
    
            
    pygame.display.update()
    clock.tick(90)

pygame.display.quit()
pygame.quit()
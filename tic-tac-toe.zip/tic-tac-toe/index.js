const box1 = document.querySelector(".box1");
const box2 = document.querySelector(".box2");
const box3 = document.querySelector(".box3");
const box4 = document.querySelector(".box4");
const box5 = document.querySelector(".box5");
const box6 = document.querySelector(".box6");
const box7 = document.querySelector(".box7");
const box8 = document.querySelector(".box8");
const box9 = document.querySelector(".box9");
const dai1 = document.querySelector(".d1");
const dai2 = document.querySelector(".d2");
const row1 = document.querySelector(".r1");
const row2 = document.querySelector(".r2");
const row3 = document.querySelector(".r3");
const col1 = document.querySelector(".c1");
const col2 = document.querySelector(".c2");
const col3 = document.querySelector(".c3");
const okBtn = document.querySelector(".again");
const noBtn = document.querySelector(".exit");
const winner = document.querySelector(".announce");
const result = document.querySelector(".result");
// console.log(result)
let winnerX = `&#128525; X is The Winner &#128525; `;
let winnerY = `&#128525; O is The Winner &#128525; `;
let winnerNo = `&#128520; No One Wins !!! &#128520; `;
let arr = [
    [null,null,null],[null,null,null],[null,null,null]
];

// console.log(arr[0]);
// console.log(arr[1]);
// console.log(arr[2]);
let alpha = 1;
let count = 0;
let clicked = (e) => {
    const text1 = `<h1 class="head">X</h1>`;
    const text2 = `<h1 class="head">O</h1>`;
    
    let check = e.target.innerText;
    if (check == 1) {
        if(arr[0][0] == null){
            count++;
            arr[0][0] = parseInt(alpha);    
            if (alpha == 1) {            
                alpha = 5;
                box1.innerHTML = text1;
            }else {            
                alpha = 1;
                box1.innerHTML = text2;
            }
        }
    }else if(check==2) {
        if(arr[0][1] == null){
            count++;
            arr[0][1] = parseInt(alpha);        
            if (alpha == 1) {            
                alpha = 5;
                box2.innerHTML = text1;
            }else {            
                alpha = 1;
                box2.innerHTML = text2;
            }
        }
    }else if(check==3) {
        if(arr[0][2] == null){
            count++;
            arr[0][2] = parseInt(alpha);        
            if (alpha == 1) {            
                alpha = 5;
                box3.innerHTML = text1;
            }else {            
                alpha = 1;
                box3.innerHTML = text2;
            }
        }
    }else if(check==4) {
        if(arr[1][0] == null){
            count++;
            arr[1][0] = parseInt(alpha);        
            if (alpha == 1) {            
                alpha = 5;
                box4.innerHTML = text1;
            }else {            
                alpha = 1;
                box4.innerHTML = text2;
            }
        }
    }else if(check==5) {
        if(arr[1][1] == null){
            count++;
            arr[1][1] = parseInt(alpha);        
            if (alpha == 1) {            
                alpha = 5;
                box5.innerHTML = text1;
            }else {            
                alpha = 1;
                box5.innerHTML = text2;
            }
        }
    }else if(check==6) {
        if(arr[1][2] == null){
            count++;
            arr[1][2] = parseInt(alpha);        
            if (alpha == 1) {            
                alpha = 5;
                box6.innerHTML = text1;
            }else {            
                alpha = 1;
                box6.innerHTML = text2;
            }
        }
    }else if(check==7) {
        if(arr[2][0] == null){
            count++;
            arr[2][0] = parseInt(alpha);        
            if (alpha == 1) {            
                alpha = 5;
                box7.innerHTML = text1;
            }else {            
                alpha = 1;
                box7.innerHTML = text2;
            }
        }
    }else if(check==8) {
        if(arr[2][1] == null){
            count++;
            arr[2][1] = parseInt(alpha);        
            if (alpha == 1) {            
                alpha = 5;
                box8.innerHTML = text1;
            }else {            
                alpha = 1;
                box8.innerHTML = text2;
            }
        }
    }else if(check==9) {
        if(arr[2][2] == null){
            count++;
            arr[2][2] = parseInt(alpha);        
            if (alpha == 1) {            
                alpha = 5;
                box9.innerHTML = text1;
            }else {            
                alpha = 1;
                box9.innerHTML = text2;
            }
        }
    }

    setTimeout("winnerChecking()", 100);
    
// console.log(arr[0]);
// console.log(arr[1]);
// console.log(arr[2]);
// console.log(count);
}
let i = 0, j = 0;
let winnerChecking = () => {    
    let d1=0,d2=0,r1=0,r2=0,r3=0,c1=0,c2=0,c3=0;
    // console.log(d1);
    for(i=0;i<=2;i++){
        for(j=0;j<=2;j++){
            if( i == j)
                d1 += arr[i][j];
            if( i+j == 2)
                d2 += arr[i][j];
            if( i==0)
                r1 += arr[i][j];
            if( i==1)
                r2 += arr[i][j];
            if( i==2)
                r3 += arr[i][j];
            if( j==0)
                c1 += arr[i][j];
            if( j==1)
                c2 += arr[i][j];
            if( j==2)
                c3 += arr[i][j];

        }
    }

    
//============= diagonal 1 =========
    if(d1 == 3){
        winner.innerHTML = winnerX;
        dai1.style.display="block";
        caller();
        return;
    }else if(d1 == 15){
        winner.innerHTML = winnerY;
        dai1.style.display="block";
        caller();
        return;
    }
//============ diagonal 2 ==========
    if(d2 == 3){
        winner.innerHTML = winnerX;
        dai2.style.display="block";
        caller();
        return;
    }else if(d2 == 15){
        winner.innerHTML = winnerY;
        dai2.style.display="block";
        caller();
        return;
    }
//============ row 1 ===========
    if(r1 == 3){
        winner.innerHTML = winnerX;
        row1.style.display="block";
        caller();
        return;
    }else if(r1 == 15){
        winner.innerHTML = winnerY;
        row1.style.display="block";
        caller();
        return;
    }
//============ row 2 =========
    if(r2 == 3){
        winner.innerHTML = winnerX;
        row2.style.display="block";
        caller();
        return;
    }else if(r2 == 15){
        winner.innerHTML = winnerY;
        row2.style.display="block";
        caller();
        return;
    }
//============= row 3 ==========
    if(r3 == 3){
        winner.innerHTML = winnerX;
        row3.style.display="block";
        caller();
        return;
    }else if(r3 == 15){
        winner.innerHTML = winnerY;
        row3.style.display="block";
        caller();
        return;
    }
//============= column 1 ===========
    if(c1 == 3){
        winner.innerHTML = winnerX;
        col1.style.display="block";
        caller();
        return;
    }else if(c1 == 15){
        winner.innerHTML = winnerY;
        col1.style.display="block";
        caller();
        return;
    }
//============= column 2 ===========
    if(c2 == 3){
        winner.innerHTML = winnerX;
        col2.style.display="block";
        caller();
        return;
    }else if(c2 == 15){
        winner.innerHTML = winnerY;
        col2.style.display="block";
        caller();
        return;
    }
//============= column 3 ===========
    if(c3 == 3){
        winner.innerHTML = winnerX;
        col3.style.display="block";
        caller();
        return;
    }else if(c3 == 15){
        winner.innerHTML = winnerY;
        col3.style.display="block";
        caller();
        return;
    }
    if(count == 9){
        winner.innerHTML = winnerNo;
        caller();
    }
        
}
const caller =()=> setTimeout("winnerCall()",1000);
function winnerCall(){    
    result.classList.toggle('result1');
}
box1.addEventListener("click", clicked);
box2.addEventListener("click", clicked);
box3.addEventListener("click", clicked);
box4.addEventListener("click", clicked);
box5.addEventListener("click", clicked);
box6.addEventListener("click", clicked);
box7.addEventListener("click", clicked);
box8.addEventListener("click", clicked);
box9.addEventListener("click", clicked);

okBtn.addEventListener("click",()=>{
    window.location.reload();
})
noBtn.addEventListener("click",()=>{
    window.close();
})

// for (i = 0; i <= 2; i++){
//     for (j = 0; j <= 2; j++)
//         console.log(arr[i][j]);
// }

